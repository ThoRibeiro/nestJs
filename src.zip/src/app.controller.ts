import { Body, Controller, Delete, Get, Param, Post, Put } from '@nestjs/common';
import { AppService } from './app.service';
import { Product } from './interfaces/product';

@Controller('product')
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  getAllProducts(): Product[] {
    return this.appService.getAllProducts();
  }

  @Post()
  createProduct(@Body() product: Product): Product {
    return this.appService.createProduct(product);
  }

  @Put(':id')
  updateProduct(@Param('id') id: number, @Body() updatedProduct: Product): Product {
    return this.appService.updateProduct(Number(id), updatedProduct);
  }

  @Delete(':id')
  deleteProduct(@Param('id') id: number): boolean {
    return this.appService.deleteProduct(Number(id));
  }
}
